// UK lang variables

tinyMCE.addToLang('youtube',{
title : 'Insert / edit YouTube Movie',
desc : 'Insert / edit YouTube Movie',
file : 'YouTube URL',
size : 'Size',
general : 'General'
});
