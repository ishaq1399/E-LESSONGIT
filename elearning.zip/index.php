<?php
header ('location:login');
?>